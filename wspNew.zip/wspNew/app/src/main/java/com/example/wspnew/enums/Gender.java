package com.example.wspnew.enums;

public enum Gender {
    MALE, FEMALE, OTHER, WALMART_BAG
}
