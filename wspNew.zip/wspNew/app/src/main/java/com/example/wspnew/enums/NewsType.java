package com.example.wspnew.enums;

public enum NewsType {
	INFORMATION, WARNING
}
