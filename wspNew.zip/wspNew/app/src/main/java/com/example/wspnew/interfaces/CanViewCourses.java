package com.example.wspnew.interfaces;

public interface CanViewCourses {
    public void viewCourses();
}
