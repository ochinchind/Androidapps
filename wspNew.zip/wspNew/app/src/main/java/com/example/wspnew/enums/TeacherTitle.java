package com.example.wspnew.enums;

public enum TeacherTitle {
	PROFESSOR, LECTOR, SENIOR_LECTOR, TUTOR
}
